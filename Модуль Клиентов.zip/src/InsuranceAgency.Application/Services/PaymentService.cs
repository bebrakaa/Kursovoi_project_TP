﻿using System;
using System.Threading.Tasks;
using InsuranceAgency.Application.Common;
using InsuranceAgency.Application.DTOs.Payment;
using InsuranceAgency.Application.Interfaces.External;
using InsuranceAgency.Application.Interfaces.Repositories;
using InsuranceAgency.Application.Interfaces.Services;
using InsuranceAgency.Domain.Entities;

namespace InsuranceAgency.Application.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _payments;
        private readonly IContractRepository _contracts;
        private readonly IPaymentGateway _gateway;

        public PaymentService(
            IPaymentRepository payments,
            IContractRepository contracts,
            IPaymentGateway gateway)
        {
            _payments = payments;
            _contracts = contracts;
            _gateway = gateway;
        }

        public async Task<Result<PaymentResultDto>> InitiatePaymentAsync(InitiatePaymentDto dto)
        {
            var contract = await _contracts.GetByIdAsync(dto.ContractId);
            if (contract == null)
                return Result<PaymentResultDto>.Fail("Contract not found");

            var payment = new Payment(contract.Id, dto.Amount);
            await _payments.AddAsync(payment);
            await _payments.SaveChangesAsync();

            payment.MarkProcessing();
            await _payments.UpdateAsync(payment);
            await _payments.SaveChangesAsync();

            var result = await _gateway.ProcessPaymentAsync(
                dto.Amount,
                "RUB",
                payment.Id.ToString());

            if (!result.success)
            {
                payment.MarkFailed(result.error);
                await _payments.UpdateAsync(payment);
                await _payments.SaveChangesAsync();
                return Result<PaymentResultDto>.Fail(result.error ?? "Payment failed");
            }

            payment.MarkConfirmed(result.transactionId!);
            await _payments.UpdateAsync(payment);
            await _payments.SaveChangesAsync();

            contract.MarkAsPaid();
            await _contracts.UpdateAsync(contract);
            await _contracts.SaveChangesAsync();

            return Result<PaymentResultDto>.Ok(new PaymentResultDto
            {
                Success = true,
                TransactionId = result.transactionId
            });
        }
    }
}
