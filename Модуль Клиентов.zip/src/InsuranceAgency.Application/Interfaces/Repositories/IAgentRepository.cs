﻿using System;
using System.Threading.Tasks;
using InsuranceAgency.Domain.Entities;

namespace InsuranceAgency.Application.Interfaces
{
    public interface IAgentRepository
    {
        Task<Agent?> GetByIdAsync(Guid id);
    }
}
