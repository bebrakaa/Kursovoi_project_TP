using InsuranceAgency.Application.Interfaces;
using InsuranceAgency.Domain.Entities;
using InsuranceAgency.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace InsuranceAgency.Infrastructure.Repositories;

public class AgentRepository : IAgentRepository
{
    private readonly ApplicationDbContext _db;

    public AgentRepository(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task<Agent?> GetByIdAsync(Guid id)
    {
        return await _db.Agents.FirstOrDefaultAsync(a => a.Id == id);
    }
}

