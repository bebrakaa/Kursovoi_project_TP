﻿namespace InsuranceAgency.Domain.Enums
{
    public enum UserRole
    {
        Administrator,
        Agent,
        Client
    }
}
