using Microsoft.AspNetCore.Mvc;

namespace InsuranceAgency.Web.Controllers;

/// <summary>
/// MVC-контроллер для страниц регистрации и входа.
/// Сами операции выполняются через API /api/Auth.
/// </summary>
public class AccountController : Controller
{
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }
}


