using System.Net;
using System.Net.Http.Json;
using InsuranceAgency.Application.DTOs;
using InsuranceAgency.Domain.Entities;
using InsuranceAgency.Domain.ValueObjects;
using InsuranceAgency.Infrastructure.Persistence;
using InsuranceAgency.Web;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace InsuranceAgency.Tests.Integration;

public class ContractsApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    private readonly HttpClient _client;

    public ContractsApiTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.UseEnvironment("Testing");
            builder.ConfigureServices(services =>
            {
                // Remove the real DbContext
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<ApplicationDbContext>));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // Add InMemory database
                services.AddDbContext<ApplicationDbContext>(options =>
                {
                    options.UseInMemoryDatabase("TestDb_" + Guid.NewGuid());
                });
            });
        });

        _client = _factory.CreateClient();
    }

    [Fact]
    public async Task GetContracts_ReturnsOk()
    {
        // Act
        var response = await _client.GetAsync("/api/contracts");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task GetContractById_WithExistingId_ReturnsOk()
    {
        // Arrange
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        var client = new Client("Test Client", "test@example.com", "+1234567890", "1234567890");
        var service = new InsuranceService("Test Service", new Money(10000m, "RUB"));
        var agent = new Agent("Test Agent", "agent@example.com");

        db.Clients.Add(client);
        db.InsuranceServices.Add(service);
        db.Agents.Add(agent);
        await db.SaveChangesAsync();

        var contract = new Contract(
            client.Id,
            service.Id,
            DateOnly.FromDateTime(DateTime.UtcNow),
            DateOnly.FromDateTime(DateTime.UtcNow.AddDays(365)),
            new Money(10000m, "RUB"),
            agent.Id);
        contract.Register("CTR-001", agent.Id);

        db.Contracts.Add(contract);
        await db.SaveChangesAsync();

        // Act
        var response = await _client.GetAsync($"/api/contracts/{contract.Id}");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var contractDto = await response.Content.ReadFromJsonAsync<ContractDto>();
        contractDto.Should().NotBeNull();
        contractDto!.Id.Should().Be(contract.Id);
    }

    [Fact]
    public async Task GetContractById_WithNonExistentId_ReturnsNotFound()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act
        var response = await _client.GetAsync($"/api/contracts/{nonExistentId}");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreateContract_WithValidData_ReturnsCreated()
    {
        // Arrange
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        var client = new Client("Test Client", "test@example.com", "+1234567890", "1234567890");
        var service = new InsuranceService("Test Service", new Money(10000m, "RUB"));
        var agent = new Agent("Test Agent", "agent@example.com");

        db.Clients.Add(client);
        db.InsuranceServices.Add(service);
        db.Agents.Add(agent);
        await db.SaveChangesAsync();

        var dto = new CreateContractDto
        {
            ClientId = client.Id,
            ServiceId = service.Id,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(365),
            PremiumAmount = 10000m,
            PremiumCurrency = "RUB"
        };

        // Act
        var response = await _client.PostAsJsonAsync($"/api/contracts?agentId={agent.Id}", dto);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        var contractDto = await response.Content.ReadFromJsonAsync<ContractDto>();
        contractDto.Should().NotBeNull();
        contractDto!.ClientId.Should().Be(client.Id);
        contractDto.ServiceId.Should().Be(service.Id);
    }
}

