using Microsoft.AspNetCore.Mvc;

namespace InsuranceAgency.Web.Controllers;

/// <summary>
/// Простые MVC-страницы для демонстрации сайта.
/// </summary>
public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Dashboard()
    {
        // Здесь в реальном приложении можно было бы использовать куки/claims.
        return View();
    }
}


