﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using InsuranceAgency.Application.DTOs;

namespace InsuranceAgency.Application.Interfaces
{
    public interface IContractService
    {
        Task<ContractDto> CreateContractAsync(CreateContractDto dto, Guid agentId);
        Task<ContractDto> RegisterContractAsync(Guid contractId, string number, Guid agentId);

        Task<IEnumerable<ContractDto>> GetAllAsync();
        Task<ContractDto?> GetByIdAsync(Guid id);
    }
}
